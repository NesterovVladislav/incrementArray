//
//  AppDelegate.h
//  incrementArrayNesterov
//
//  Created by Nesterov on 03/03/17.
//  Copyright © 2017 Nesterov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

